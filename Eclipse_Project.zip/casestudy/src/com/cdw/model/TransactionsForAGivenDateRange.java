package com.cdw.model;

public class TransactionsForAGivenDateRange {
	private int	   transactionId;
	private int    ssn;
	private String creditCardNo;
	private Double transactionValue;
	private String transactions;
	private String transactionYear;
	private String transactionMonth;
	private String transactionDay;
	
	public TransactionsForAGivenDateRange(int transactionId, int ssn, String creditCardNo, Double transactionValue, String transactions,
											String transactionYear, String transactionMonth, String transactionDay) {
		super();
		this.transactionId = transactionId;
		this.ssn = ssn;
		this.creditCardNo = creditCardNo;
		this.transactionValue = transactionValue;
		this.transactions = transactions;
		this.transactionYear = transactionYear;
		this.transactionMonth = transactionMonth;
		this.transactionDay = transactionDay;
	}
	
	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public Double getTransactionValue() {
		return transactionValue;
	}

	public void setTransactionValue(Double transactionValue) {
		this.transactionValue = transactionValue;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public String getTransactionYear() {
		return transactionYear;
	}

	public void setTransactionYear(String transactionYear) {
		this.transactionYear = transactionYear;
	}

	public String getTransactionMonth() {
		return transactionMonth;
	}

	public void setTransactionMonth(String transactionMonth) {
		this.transactionMonth = transactionMonth;
	}

	public String getTransactionDay() {
		return transactionDay;
	}

	public void setTransactionDay(String transactionDay) {
		this.transactionDay = transactionDay;
	}

	
	public String toString() {
		return "TransactionsForAGivenDateRange [transactionId=" + transactionId
				+ ", ssn=" + ssn + ", creditCardNo=" + creditCardNo
				+ ", transactionValue=" + transactionValue + ", transactions="
				+ transactions + ", transactionYear=" + transactionYear
				+ ", transactionMonth=" + transactionMonth
				+ ", transactionDay=" + transactionDay + "]";
	}
	
}
