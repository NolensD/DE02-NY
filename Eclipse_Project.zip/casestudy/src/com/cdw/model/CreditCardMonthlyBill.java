package com.cdw.model;

public class CreditCardMonthlyBill {
	private int transactionID;
	private int day;
	private int month;
	private int year;
	private String creditCardNo;
	private int custSSN;
	private int branchCode;
	private String transactionType;
	private double transactionValue;
	
	public CreditCardMonthlyBill() {
		super();
		this.transactionID = 0;
		this.day = 0;
		this.month =0;
		this.year = 0;
		this.creditCardNo = "";
		this.custSSN = 0;
		this.branchCode = 0;
		this.transactionType = "";
		this.transactionValue = 0;
	}
	
	public CreditCardMonthlyBill(int transactionID, int day, int month,
			int year, String creditCardNo, int custSSN, int branchCode,
			String transactionType, double transactionValue) {
		super();
		this.transactionID = transactionID;
		this.day = day;
		this.month = month;
		this.year = year;
		this.creditCardNo = creditCardNo;
		this.custSSN = custSSN;
		this.branchCode = branchCode;
		this.transactionType = transactionType;
		this.transactionValue = transactionValue;
	}
	
	

	public int getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public int getCustSSN() {
		return custSSN;
	}

	public void setCustSSN(int custSSN) {
		this.custSSN = custSSN;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getTransactionValue() {
		return transactionValue;
	}

	public void setTransactionValue(double transactionValue) {
		this.transactionValue = transactionValue;
	}

	public String toString() {
		return "CreditCardMonthlyBill [transactionID=" + transactionID
				+ ", day=" + day + ", month=" + month + ", year=" + year
				+ ", creditCardNo=" + creditCardNo + ", custSSN=" + custSSN
				+ ", branchCode=" + branchCode + ", transactionType="
				+ transactionType + ", transactionValue=" + transactionValue
				+ "]";
	}
	
	
	
	
	
}
