package com.cdw.model;

public class TransactionForAGivenDate {
	private int	   transactionId;
	private int    ssn;
	private String creditCardNo;
	private Double transactionValue;
	private String transactions;
	private String customerZip;
	private String transactionDay;
	private String transactionMonth;
	private String transactionYear;
	

	public TransactionForAGivenDate(int transactionId, int ssn, String creditCardNo, Double transactionValue, String transactions,
									 String customerZip, String transactionDay, String transactionMonth, String transactionYear) {
	super();
	this.transactionId = transactionId;
	this.ssn = ssn;
	this.creditCardNo = creditCardNo;
	this.transactionValue = transactionValue;
	this.transactions = transactions;
	this.customerZip = customerZip;
	this.transactionDay = transactionDay;
	this.transactionMonth = transactionMonth;
	this.transactionYear = transactionYear;
}
	
	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public Double getTransactionValue() {
		return transactionValue;
	}

	public void setTransactionValue(Double transactionValue) {
		this.transactionValue = transactionValue;
	}


	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public String getCustomerZip() {
		return customerZip;
	}

	public void setCustomerZip(String customerZip) {
		this.customerZip = customerZip;
	}


	public String getTransactionDay() {
		return transactionDay;
	}


	public void setTransactionDay(String transactionDay) {
		this.transactionDay = transactionDay;
	}


	public String getTransactionMonth() {
		return transactionMonth;
	}


	public void setTransactionMonth(String transactionMonth) {
		this.transactionMonth = transactionMonth;
	}


	public String getTransactionYear() {
		return transactionYear;
	}

	public void setTransactionYear(String transactionYear) {
		this.transactionYear = transactionYear;
	}


	public String toString() {
		return "TransactionForAGivenDate [transactionId=" + transactionId
				+ ", ssn=" + ssn + ", creditCardNo=" + creditCardNo
				+ ", transactionValue=" + transactionValue + ", transactions="
				+ transactions + ", customerZip=" + customerZip
				+ ", transactionDay=" + transactionDay + ", transactionMonth="
				+ transactionMonth + ", transactionYear=" + transactionYear
				+ "]";
	}
	
}	