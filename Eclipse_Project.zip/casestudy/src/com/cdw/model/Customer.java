package com.cdw.model;

public class Customer {
	
	private String firstName;
	private String MiddleName;
	private String LastName;
	private int ssn;
	private String creditCardNo;
	private String aptNo;
	private String streetName;
	private String city;
	private String state;
	private String country;
	private String zip;
	private int phone;
	private String email;
	
	
	
	public Customer() {
		super();
		this.firstName = "";
		this.MiddleName = "";
		this.LastName = "";
		this.ssn = 0;
		this.creditCardNo = "";
		this.aptNo = "";
		this.streetName = "";
		this.city = "";
		this.state = "";
		this.country = "";
		this.zip = "";
		this.phone = 0;
		this.email = "";
	}
	
	public Customer(String firstName, String middleName,
			String lastName, int ssn, String creditCardNo, String aptNo,
			String streetName, String city, String state, String country,
			String zip, int phone, String email) {
		super();
		this.firstName = firstName;
		MiddleName = middleName;
		LastName = lastName;
		this.ssn = ssn;
		this.creditCardNo = creditCardNo;
		this.aptNo = aptNo;
		this.streetName = streetName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.phone = phone;
		this.email = email;
	}
	
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return MiddleName;
	}

	public void setMiddleName(String middleName) {
		this.MiddleName = middleName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		this.LastName = lastName;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getAptNo() {
		return aptNo;
	}

	public void setAptNo(String aptNo) {
		this.aptNo = aptNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return "Customer [firstName=" + firstName
				+ ", MiddleName=" + MiddleName + ", LastName=" + LastName
				+ ", ssn=" + ssn + ", creditCardNo=" + creditCardNo
				+ ", aptNo=" + aptNo + ", streetName=" + streetName + ", city="
				+ city + ", state=" + state + ", country=" + country + ", zip="
				+ zip + ", phone=" + phone + ", email=" + email + "]";
	}
	
}
