package com.cdw.model;

public class TransactionForAGivenState {
	private String transactionBranchesCity;
	private String countTransactions;
	private String sumTransactionValue;
	
	public TransactionForAGivenState(String transactionBranchesCity,
			String countTransactions, String sumTransactionValue) {
		super();
		this.transactionBranchesCity = transactionBranchesCity;
		this.countTransactions = countTransactions;
		this.sumTransactionValue = sumTransactionValue;
	}
	
	

	public String getTransactionBranchesCity() {
		return transactionBranchesCity;
	}

	public void setTransactionBranchesCity(String transactionBranchesCity) {
		this.transactionBranchesCity = transactionBranchesCity;
	}

	public String getCountTransactions() {
		return countTransactions;
	}

	public void setCountTransactions(String countTransactions) {
		this.countTransactions = countTransactions;
	}

	public String getSumTransactionValue() {
		return sumTransactionValue;
	}

	public void setSumTransactionValue(String sumTransactionValue) {
		this.sumTransactionValue = sumTransactionValue;
	}


	public String toString() {
		return "TransactionForAGivenState [transactionBranchesCity="
				+ transactionBranchesCity + ", countTransactions="
				+ countTransactions + ", sumTransactionValue="
				+ sumTransactionValue + "]";
	}

	

	
}
