package com.cdw.model;

public class TransactionForAGivenType {
	private String countTransactionType;
	private String sumTransactionValue;
	private String transactionType;
	
	public TransactionForAGivenType(String countTransactionType,
			String sumTransactionValue, String transactionType) {
		
		super();
		this.countTransactionType = countTransactionType;
		this.sumTransactionValue = sumTransactionValue;
		this.transactionType = transactionType;
	}
	
	
	public String getCountTransactionType() {
		return countTransactionType;
	}

	public void setCountTransactionType(String countTransactionType) {
		this.countTransactionType = countTransactionType;
	}

	public String getSumTransactionValue() {
		return sumTransactionValue;
	}

	public void setSumTransactionValue(String sumTransactionValue) {
		this.sumTransactionValue = sumTransactionValue;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String toString() {
		return "TransactionForAGivenType [countTransactionType="
				+ countTransactionType + ", sumTransactionValue="
				+ sumTransactionValue + ", transactionType=" + transactionType
				+ "]";
	}
	
	
	
	
}
