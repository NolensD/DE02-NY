package com.cdw.csvfile;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import com.cdw.dao.CreditCardDAO;
import com.cdw.dao.TransactionDAO;
import com.cdw.model.CreditCardMonthlyBill;
import com.cdw.model.TransactionForAGivenDate;
import com.cdw.model.TransactionForAGivenState;
import com.cdw.model.TransactionsForAGivenDateRange;

public class GenerateCSVfile {

	//This method exports to a .csv a monthly Bill given the creditcard no, ssn, month and year
	public static void CreateCSVfileMonthlyBillGivenCreditCardNo(int SSN, String creditCardNo, String month, String year) {
		CreditCardDAO ccDAO = new CreditCardDAO();
		
		if ((SSN <= 0) ||(creditCardNo.isEmpty()) || (month.isEmpty()) || (year.isEmpty())) {
			///do not create csv file
		}
		else { 
			ArrayList<CreditCardMonthlyBill> MonthlyBill = ccDAO.queryDisplayMonthlyBillGivenCreditCardNo(SSN, creditCardNo, Integer.parseInt(month), Integer.parseInt(year));
			
			FileWriter writer = null;
	
		 try {
			 String fileName = "c:\\nolens\\MonthlyBillGivenCreditCardNo.csv";
			 writer = new FileWriter(fileName);
			 
		     writer.append("TRANSACTION_ID");
		     writer.append(',');
		     writer.append("DAY");
		     writer.append(',');
		     writer.append("MONTH");
		     writer.append(',');
		     writer.append("YEAR");
		     writer.append(',');
		     writer.append("CREDIT_CARD_NO");
		     writer.append(',');
		     writer.append("CUSTOMER_SSN");
		     writer.append(',');
		     writer.append("BRANCH_CODE");
		     writer.append(',');
		     writer.append("TRANSACTION_TYPE");
		     writer.append(',');
		     writer.append("TRANSACTION_VALUE");
		     writer.append('\n');
		     
			 for (int i = 0; i < MonthlyBill.size(); i++) {				
				writer.append(MonthlyBill.get(i).getTransactionID() + "," + MonthlyBill.get(i).getDay() + "," +
							  MonthlyBill.get(i).getMonth() + "," + MonthlyBill.get(i).getYear() + "," + MonthlyBill.get(i).getCreditCardNo() + "," +
		                      MonthlyBill.get(i).getCustSSN() + "," + MonthlyBill.get(i).getBranchCode() + "," + MonthlyBill.get(i).getTransactionType() + "," + 
		                      MonthlyBill.get(i).getTransactionValue());
				 writer.append('\n');
			}
			 
			 if (MonthlyBill.size() > 0) {
				 System.out.println("CSV file is created..."); 
			 }
	
		 } catch (IOException e) {
		     e.printStackTrace();
		 } finally {
		        try {
		        	writer.flush();
		        	writer.close();
		        } catch (IOException e) {
		        	e.printStackTrace();
		        }
		 }
	  }
	}
	
	//This method exports to a .csv transactions made by a customer...given a date range. 
	public static void CreateCSVfileForADateRange(int SSN, Date sqlBeginDate, Date sqlEndDate)  {
			TransactionDAO tDAO = new TransactionDAO();
			 
			ArrayList<TransactionsForAGivenDateRange> transByDateRange = tDAO.queryTransMadeByCustBetDates(SSN, sqlBeginDate, sqlEndDate);
			
			FileWriter writer = null;

		try {
			 String fileName = "c:\\nolens\\TransactionsForAGivenDateRange.csv";
			 writer = new FileWriter(fileName);
			 
		     writer.append("TRANSACTION_ID");
		     writer.append(',');
		     writer.append("CUST_SSN");
		     writer.append(',');
		     writer.append("CREDIT_CARD_NO");
		     writer.append(',');
		     writer.append("TRANSACTION_VALUE");
		     writer.append(',');
		     writer.append("TRANSACTION_TYPE");
		     writer.append(',');
		     writer.append("YEAR");
		     writer.append(',');
		     writer.append("MONTH");
		     writer.append(',');
		     writer.append("DAY");
		     writer.append('\n');
				
			 for (int i = 0; i < transByDateRange.size(); i++) {	
				 writer.append(transByDateRange.get(i).getTransactionId() + "," + transByDateRange.get(i).getSsn() + "," + 
							  transByDateRange.get(i).getCreditCardNo() + "," + transByDateRange.get(i).getTransactionValue() + "," + 
							  transByDateRange.get(i).getTransactions() + "," + transByDateRange.get(i).getTransactionYear() + "," + 
							  transByDateRange.get(i).getTransactionMonth() + "," + transByDateRange.get(i).getTransactionDay());
				 
				 writer.append('\n');
			}
			 
			 if (transByDateRange.size() > 0) {
				 System.out.println("CSV file is created..."); 
			 }

		} catch (IOException e) {
			     e.printStackTrace();
		} finally {
			    try {
			      writer.flush();
			      writer.close();
			    } catch (IOException e) {
			      e.printStackTrace();
			    }
		}
	}
		
	//This method exports to a .csv transactions made by customers...living in a given zipcode for a given month and year. 
	public static void CreateCSVfileForAGivenDate(String zip, String month, String year)  {
			TransactionDAO tDAO = new TransactionDAO();
			 
			ArrayList<TransactionForAGivenDate> transByDate = tDAO.queryTransMadeByCust(zip, month, year);
			
			FileWriter writer = null;

		 try {
			 String fileName = "c:\\nolens\\TransactionsForAGivenDate.csv";
			 writer = new FileWriter(fileName);
			 
		     writer.append("TRANSACTION_ID");
		     writer.append(',');
		     writer.append("CUST_SSN");
		     writer.append(',');
		     writer.append("CREDIT_CARD_NO");
		     writer.append(',');
		     writer.append("TRANSACTION_VALUE");
		     writer.append(',');
		     writer.append("TRANSACTION_TYPE");
		     writer.append(',');
		     writer.append("CUSTOMER_ZIP");
		     writer.append(',');
		     writer.append("DAY");
		     writer.append(',');
		     writer.append("MONTH");
		     writer.append(',');
		     writer.append("YEAR");
		     writer.append('\n');
		     
				
			 for (int i = 0; i < transByDate.size(); i++) {	
				 writer.append(transByDate.get(i).getTransactionId() + "," +  transByDate.get(i).getSsn() + "," +  
						 	   transByDate.get(i).getCreditCardNo() + "," + transByDate.get(i).getTransactionValue()  + "," + 
						 	   transByDate.get(i).getTransactions() + "," +   transByDate.get(i).getCustomerZip() + "," +  
						 	   transByDate.get(i).getTransactionDay() + "," + transByDate.get(i).getTransactionMonth() + "," + 
						 	   transByDate.get(i).getTransactionYear());
				 
				 writer.append('\n');
			}
			 
			 if (transByDate.size() > 0) {
				 System.out.println("CSV file is created..."); 
			 }

		  } catch (IOException e) {
		     e.printStackTrace();
		  } finally {
		        try {
		      writer.flush();
		      writer.close();
		        } catch (IOException e) {
		      e.printStackTrace();
		      }
		  }
	}
	
	//This method exports to a .csv displaying the  number of transactions and total values of transactions for a given State.   
	public static void CreateCSVfileForAGivenState(String transState)  {
			TransactionDAO tDAO = new TransactionDAO();
			 
			ArrayList<TransactionForAGivenState> transByState = tDAO.queryDisplayTransactionsTotalValueGivenState(transState);
			
			FileWriter writer = null;

		 try {
			 String fileName = "c:\\nolens\\TransactionsForAGivenState.csv";
			 writer = new FileWriter(fileName);
			 
		     writer.append("BRANCH CITY");
		     writer.append(',');
		     writer.append("TOTAL_#_OF_TRANSACTIONS");
		     writer.append(',');
		     writer.append("SUM_OF_ALL_TRANSACTIONS");
		     writer.append('\n');
		     
	
			 for (int i = 0; i < transByState.size(); i++) {	
				 
				 writer.append(transByState.get(i).getTransactionBranchesCity()  + "," +   transByState.get(i).getCountTransactions()  + "," +  
						 	   transByState.get(i).getSumTransactionValue());
				 
				 writer.append('\n');
			}

			 if (transByState.size() > 0) {
				 System.out.println("CSV file is created..."); 
			 }

		  } catch (IOException e) {
		     e.printStackTrace();
		  } finally {
		        try {
		      writer.flush();
		      writer.close();
		        } catch (IOException e) {
		      e.printStackTrace();
		      }
		  }
	}
	
}
