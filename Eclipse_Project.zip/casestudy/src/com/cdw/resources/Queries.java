package com.cdw.resources;

public class Queries {
	public final static String GET_CUSTOMER_BY_SSN =          "SELECT * FROM CDW_SAPP_CUSTOMER WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_FIRST_NAME =   "UPDATE CDW_SAPP_CUSTOMER SET FIRST_NAME=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_MIDDLE_NAME =  "UPDATE CDW_SAPP_CUSTOMER SET MIDDLE_NAME=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_LAST_NAME =    "UPDATE CDW_SAPP_CUSTOMER SET LAST_NAME=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_CREDIT_CARD =  "UPDATE CDW_SAPP_CUSTOMER SET CREDIT_CARD_NO=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_APT_NO =       "UPDATE CDW_SAPP_CUSTOMER SET APT_NO=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_STREET_NAME =  "UPDATE CDW_SAPP_CUSTOMER SET STREET_NAME=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_CITY =         "UPDATE CDW_SAPP_CUSTOMER SET CUST_CITY=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_STATE =        "UPDATE CDW_SAPP_CUSTOMER SET CUST_STATE=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_COUNTRY =      "UPDATE CDW_SAPP_CUSTOMER SET CUST_COUNTRY=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_ZIP =          "UPDATE CDW_SAPP_CUSTOMER SET CUST_ZIP=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_PHONE =        "UPDATE CDW_SAPP_CUSTOMER SET CUST_PHONE=? WHERE SSN=?";
	public final static String UPDATE_CUSTOMER_EMAIL =        "UPDATE CDW_SAPP_CUSTOMER SET CUST_EMAIL=? WHERE SSN=?";
	public final static String GET_TRANS_DETAIL_BY_DATE =	  "select a.TRANSACTION_ID, a.CUST_SSN, a.CREDIT_CARD_NO, a.TRANSACTION_VALUE, a.TRANSACTION_TYPE, b.CUST_ZIP, a.DAY, a.MONTH, a.YEAR " +
															  "from CDW_SAPP_CREDITCARD a join CDW_SAPP_CUSTOMER b " +
															  "on a.CREDIT_CARD_NO = b.CREDIT_CARD_NO " +
															  "where b.CUST_ZIP = ? and " +
															  "a.MONTH =? and " +
															  "a.YEAR =? " +
															  "order by a.DAY desc";
	public final static String GET_TRANS_DETAIL_BY_TYPE    = "select count(TRANSACTION_ID) as COUNT_TRANSACTION_ID , sum(TRANSACTION_VALUE)as SUM_TRANSACTION_VALUE, TRANSACTION_TYPE " +
															 "FROM CDW_SAPP_CREDITCARD  " +
															 "where TRANSACTION_TYPE = ?";
	public final static String GET_TRANS_DETAIL_BY_STATE =   "select a.BRANCH_CITY, count(b.TRANSACTION_ID) as COUNT_TRANSACTION_ID , sum(b.TRANSACTION_VALUE)  as SUM_TRANSACTION_VALUE " +
	                                                         "FROM CDW_SAPP_BRANCH a join CDW_SAPP_CREDITCARD b " + 
			                                                 "on a.BRANCH_CODE = b.BRANCH_CODE " + 
	                                                         "where a.BRANCH_STATE =? " + 
			                                                 "group by a.BRANCH_CITY";
	public final static String GET_MONTHLY_BILL_BY_CC =   	 "select * FROM CDW_SAPP_CREDITCARD " +
															 "where CUST_SSN =? and " +
															 "CREDIT_CARD_NO =? and " +
															 "MONTH =? and " +
															 "YEAR =? "; 
	public final static String GET_TRANS_BY_BET_DATES =		 "select a.TRANSACTION_ID, a.CUST_SSN, a.CREDIT_CARD_NO, a.TRANSACTION_VALUE, a.TRANSACTION_TYPE , a.YEAR, a.MONTH, a.DAY  " +
															 "from CDW_SAPP_CREDITCARD a join CDW_SAPP_CUSTOMER b " + 
															 "on a.CREDIT_CARD_NO = b.CREDIT_CARD_NO " +
															 "where b.SSN = ? and " +
															 "date_format(concat_ws('-',  a.YEAR, a.MONTH, a.DAY), '%Y-%m-%d') between ? and ? " +
															 "order by a.YEAR desc, a.MONTH desc,  a.DAY desc";
	
														
	private Queries() {
		//To prevent new instance of constructor...
	}
}
