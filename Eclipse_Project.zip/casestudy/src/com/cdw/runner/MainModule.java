package com.cdw.runner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.cdw.csvfile.GenerateCSVfile;
import com.cdw.dao.CreditCardDAO;
//import com.cdw.dao.AbstractDAO;
import com.cdw.dao.CustomerDAO;
import com.cdw.dao.TransactionDAO;
import com.cdw.model.CreditCardMonthlyBill;
import com.cdw.model.Customer;
import com.cdw.model.TransactionForAGivenDate;
import com.cdw.model.TransactionForAGivenState;
import com.cdw.model.TransactionForAGivenType;
import com.cdw.model.TransactionsForAGivenDateRange;


//case study....
//Author: Nolens Darbouze
//Class: Data Engineering 2


public class MainModule {
	//throws java.text.ParseException 
	public static void main(String args[]) {
		boolean exitProgram = false;
	
		do {
			switch (askUserWhatToDo()) {
				case 1: String zip = askUserForZipCode();	          // 1. View Transactions by Zipcode
						String month = askUserForMonth();
						String year = askUserForYear();
						processTransactionsForAGivenDate( zip,  month, year);
						GenerateCSVfile.CreateCSVfileForAGivenDate(zip, month, year);
						exitProgram = askUserToExitProgram();
						break;
				case 2: String transType = askUserForTransType();     // 2. View Totals By Transaction Type
						processTransactionsForAGivenType(transType);
						exitProgram = askUserToExitProgram();
						break;
				case 3: String state = askUserForAGivenState();	      // 3. View Totals By State 
						processTransactionsForAGivenState(state);
						GenerateCSVfile.CreateCSVfileForAGivenState(state);
						exitProgram = askUserToExitProgram();
						break;
				case 4: int customerSSN = askUserForCustSSN();	      // 4. View Customer Details By SSN
						processCustomerBySSN(customerSSN);
						exitProgram = askUserToExitProgram();
						break;
				case 5: int customerUpdateSSN = askUserForCustSSN();  // 5. Edit a Customer's Info
						if (processCustomerBySSN(customerUpdateSSN))  {
							updateCustomerBySSN(customerUpdateSSN);
							while (askUserToUpdateMoreFields()) {
								updateCustomerBySSN(customerUpdateSSN);
							}
							exitProgram = askUserToExitProgram();
						}				
						break;
				case 6: int customrSSN = askUserForCustSSN();		  // 6. View a Customer's Bill for a given Month 
						String CreditCardNo = askUserForCreditCardNo();
						String aMonth = askUserForMonth();
						String aYear = askUserForYear();
						processMonthlyBillForCustomer( customrSSN, CreditCardNo, aMonth, aYear);
						GenerateCSVfile.CreateCSVfileMonthlyBillGivenCreditCardNo(customrSSN, CreditCardNo, aMonth, aYear);
						exitProgram = askUserToExitProgram();
						break;
				case 7: int custSSN = askUserForCustSSN();			//  7. View a Customer's Transaction Between Two Dates				
						try {
							Date sqlBeginDate;
							sqlBeginDate = askUserForABeginDate();
							Date sqlEndDate = askUserForAEndDate();
							processTransactionsForADateRange(custSSN, sqlBeginDate, sqlEndDate );
							GenerateCSVfile.CreateCSVfileForADateRange(custSSN, sqlBeginDate, sqlEndDate);
							exitProgram = askUserToExitProgram();
							break;		
						} catch (ParseException e) {
							e.printStackTrace();
						}
				default: System.out.println("You have not entered a valid option... ");
						exitProgram = true;
						break;
			} 
		} while (exitProgram == false); 

	}
	
	public static java.sql.Date askUserForABeginDate() throws java.text.ParseException {
		String UserReturnInfoBegin = askUserForBeginDate();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    java.util.Date utilDate = format.parse(UserReturnInfoBegin);		  
	    java.sql.Date sqlBeginDate = new java.sql.Date(utilDate.getTime());   
	    
		return sqlBeginDate;
	}
	
	public static java.sql.Date askUserForAEndDate() throws java.text.ParseException {
		String UserReturnInfoEnd = askUserForEndDate();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    java.util.Date utilDate = format.parse(UserReturnInfoEnd);		  
	    java.sql.Date sqlEndDate = new java.sql.Date(utilDate.getTime());   
	    
		return sqlEndDate;
	}
	
	
	public static void processMonthlyBillForCustomer(int SSN, String creditCardNo, String month, String year) {
		CreditCardDAO ccDAO = new CreditCardDAO();
	
		if ((SSN <= 0) ||(creditCardNo.isEmpty()) || (month.isEmpty()) || (year.isEmpty())) {
			System.out.println("Sorry! No Transactions found for the given parameter values...");
		}
		else {
			//This method provides a monthly Bill given the creditcard no, ssn, month and year 
			ArrayList<CreditCardMonthlyBill> MonthlyBill = ccDAO.queryDisplayMonthlyBillGivenCreditCardNo(SSN, creditCardNo, Integer.parseInt(month), Integer.parseInt(year));
			if (MonthlyBill.size() > 0) {
				System.out.println("");
				System.out.println("TRANSACTION ID \t DAY \t MONTH \t YEAR \t CREDIT CARD # \t CUSTOMER SSN \t BRANCH CODE \t TRANSACTION TYPE \t TRANSACTION VALUE");
				System.out.println("-------------- \t --- \t ----- \t ---- \t ------------- \t ------------ \t ----------- \t ---------------- \t -----------------");
				for (int i = 0; i < MonthlyBill.size(); i++) {
					DecimalFormat myFormatter = new DecimalFormat("$###,###.###");
					String outputFormattted = myFormatter.format(MonthlyBill.get(i).getTransactionValue());
					String format = "%-16s %-10s %-5s %-5s %-7s %-18s %-15s %-20s %s %n";
					System.out.printf(format, MonthlyBill.get(i).getTransactionID(), MonthlyBill.get(i).getDay(), 
							                  MonthlyBill.get(i).getMonth(), MonthlyBill.get(i).getYear(), MonthlyBill.get(i).getCreditCardNo(),
							                  MonthlyBill.get(i).getCustSSN(), MonthlyBill.get(i).getBranchCode(), MonthlyBill.get(i).getTransactionType(), 
							                  outputFormattted);	
				}
			}
			else {
				System.out.println("Sorry! No Transactions found for the given parameter values...");	
			}	
		}			
	}
														
	public static void processTransactionsForADateRange(int SSN, Date sqlBeginDate, Date sqlEndDate) {
		TransactionDAO tDAO = new TransactionDAO();
		
		//transactions made by a customer...given a date range. 
		ArrayList<TransactionsForAGivenDateRange> transByDateRange = tDAO.queryTransMadeByCustBetDates(SSN, sqlBeginDate, sqlEndDate);
		if (transByDateRange.size() > 0) {
			System.out.println("");
			DecimalFormat myFormatter = new DecimalFormat("$###,###.###");
			System.out.println("");
			System.out.println("TRANSACTION ID \t CUST SSN \t CREDIT CARD NO \t TRANSACTION VALUE \t TRANSACTION TYPE \t YEAR \t MONTH \t DAY");
			System.out.println("-------------- \t -------- \t -------------- \t ----------------- \t ---------------- \t ---- \t ----- \t ---");
			for (int i = 0; i < transByDateRange.size(); i++) {
				String outputFormatted = myFormatter.format(transByDateRange.get(i).getTransactionValue());
				String format = "%-15s %-14s %-25s %-25s %-20s %-8s %-6s %s %n";
				System.out.printf(format,  transByDateRange.get(i).getTransactionId(), transByDateRange.get(i).getSsn(), transByDateRange.get(i).getCreditCardNo(), outputFormatted , transByDateRange.get(i).getTransactions(), transByDateRange.get(i).getTransactionYear(), 
										transByDateRange.get(i).getTransactionMonth(), transByDateRange.get(i).getTransactionDay());	
			}
		}
			else {
			System.out.println("Sorry! No Transactions found for the given parameter values...");	
		}		
	}
	
	public static void processTransactionsForAGivenDate(String zip, String month, String year) {
		TransactionDAO tDAO = new TransactionDAO();
		
		//transactions made by customers...living in a given zipcode for a given month and year. 
		ArrayList<TransactionForAGivenDate> transByDate = tDAO.queryTransMadeByCust(zip, month, year);
		if (transByDate.size() > 0) {
			DecimalFormat myFormatter = new DecimalFormat("$###,###.###");
			System.out.println("");
			System.out.println("TRANSACTION ID \t CUST SSN \t CREDIT CARD NO \t TRANSACTION VALUE \t TRANSACTION TYPE \t CUSTOMER ZIP \t DAY \t MONTH \t YEAR");
			System.out.println("-------------- \t -------- \t -------------- \t ----------------- \t ---------------- \t ------------ \t --- \t ----- \t ----");
			for (int i = 0; i < transByDate.size(); i++) {
				String outputFormatted = myFormatter.format(transByDate.get(i).getTransactionValue());
				String format = "%-15s %-14s %-25s %-25s %-25s %-14s %-8s %-6s %s %n";
				System.out.printf(format, transByDate.get(i).getTransactionId(), transByDate.get(i).getSsn(), transByDate.get(i).getCreditCardNo(), outputFormatted ,transByDate.get(i).getTransactions(), transByDate.get(i).getCustomerZip(), 
						                  transByDate.get(i).getTransactionDay(), transByDate.get(i).getTransactionMonth(), 
						                  transByDate.get(i).getTransactionYear());
				
			}
		}
			else {
			System.out.println("Sorry! No Transactions found for the given parameter values...");	
		}		
	}
														
	public static void processTransactionsForAGivenType(String transType) {
		TransactionDAO tDAO = new TransactionDAO();
		
		//This Method displays the  number of transactions and total values of transactions for a given type.  
		ArrayList<TransactionForAGivenType> transByType = tDAO.queryDisplayTransactionsTotalValue(transType);
		if (transByType.get(0).getTransactionType() != null ) {
			DecimalFormat myFormatter = new DecimalFormat("$###,###.###");
			String output = myFormatter.format(Double.parseDouble(transByType.get(0).getSumTransactionValue()));
			System.out.println("");
			System.out.println("Values for type " + transByType.get(0).getTransactionType());
			System.out.println("Total Number of Transactions: " + transByType.get(0).getCountTransactionType());
			System.out.println("Sum of Values of all Transactions: " + output );	
		}
			else {
			System.out.println("Sorry! No Transactions found for the given parameter values...");	
		}	
	}
	

	public static void processTransactionsForAGivenState(String transState) {
		TransactionDAO tDAO = new TransactionDAO();
		
		//This Method displays the  number of transactions and total values of transactions for a given State.  
		ArrayList<TransactionForAGivenState> transByState = tDAO.queryDisplayTransactionsTotalValueGivenState(transState);
		if (transByState.size() > 0) {
			DecimalFormat myFormatter = new DecimalFormat("$###,###.###");
			System.out.println("");
			System.out.println("BRANCH CITY  \t TOTAL # OF TRANSACTIONS \t SUM OF ALL TRANSACTIONS ");
			System.out.println("------------ \t ----------------------- \t ----------------------- ");
			for (int i = 0; i < transByState.size(); i++) {
				String outputFormatted = myFormatter.format(Double.parseDouble(transByState.get(i).getSumTransactionValue()));
				String format = "%-25s %-30s  %-30s %n";
				System.out.printf(format, transByState.get(i).getTransactionBranchesCity(), transByState.get(i).getCountTransactions(), outputFormatted);
				
			}
		}
			else {
			System.out.println("Sorry! No Transactions found for the given parameter values...");	
		}		
	}
	
	public static boolean processCustomerBySSN(int SSN) {
		boolean successProcess = false;
		
		CustomerDAO cDAO = new CustomerDAO();
		
		//This method queries the customer table  by ssn and returns one record.
		ArrayList<Customer>  cust;
		cust = cDAO.queryCustomerBySSN(SSN);
		
		//if (cust.get(0).getLastName() != "" ) {
		 if (cust.size() != 0 ) {
			System.out.println("");
			System.out.println("FIRST_NAME  \t MIDDLE_NAME \t LAST_NAME \t  SSN \t         CREDIT_CARD_NO \t APT_NO \t STREET_NAME \t CUST_CITY \t CUST_STATE \t CUST_COUNTRY \t CUST_ZIP \t CUST_PHONE \t CUST_EMAIL ");
			System.out.println("----------  \t ----------- \t --------- \t  --- \t         -------------- \t ------ \t ----------- \t --------- \t ---------- \t ------------ \t -------- \t ---------- \t ---------- ");
			String format = "%-15s %-15s %-15s %-15s %-20s %-20s %-15s %-15s %-15s %-15s %-15s %-10s %-10s %n";
			System.out.printf(format, cust.get(0).getFirstName(), cust.get(0).getMiddleName(), cust.get(0).getLastName(), cust.get(0).getSsn(), 
									  cust.get(0).getCreditCardNo(), cust.get(0).getAptNo(), cust.get(0).getStreetName(), cust.get(0).getCity(),		
									  cust.get(0).getState(),cust.get(0).getCountry(), cust.get(0).getZip(), cust.get(0).getPhone(), cust.get(0).getEmail());
			successProcess = true;
		 }
		else {
			System.out.println("Sorry! No Customer matching this SSN...");
			successProcess = false;
		}	
		 return successProcess;
	}
		
	public static void updateCustomerBySSN(int SSN) {
		
		String columnToBeModified;
		String modifiedValue;
		
		//This method gets user requested customer modification column name and value..
		String[] UserReturnInfo = askUserColToBeModify();
		columnToBeModified = UserReturnInfo[0];
		modifiedValue = UserReturnInfo[1];
		
		if (SSN > 0) {
			//call method to determine which column value to update for the customer details....
			CustomerDAO.UpdateCustomerDetail(columnToBeModified, modifiedValue , SSN );	
		}

		
	}
		
	public static String[] askUserColToBeModify() {
		String userInput = "";
		String[] userInputArray;
		String[] myPositionsArray = new String[2]; 

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter which customer detail you would like to modify ");
		System.out.print("by providing the field name and the new value separated by a comma: ");  

		try {
			userInput = br.readLine();
			if (userInput.isEmpty()) {
				System.out.println("Sorry No customer detail entered...");
				System.err.println("");
		        myPositionsArray[0] = "";
		        myPositionsArray[1] = "";
			}
		    else {
		    	//separate all values by comma
		    	if (userInput.contains(",")) {
		    		userInputArray = userInput.split(",");
		           
		    		myPositionsArray[0] = userInputArray[0];
		    		myPositionsArray[1] =  userInputArray[1];
		    	} else {
					System.out.print("Sorry Customer detail invalid...");
					System.err.println("");
			        myPositionsArray[0] = "";
			        myPositionsArray[1] = "";
		    	}
			}
		} catch (IOException e) {
			  
			e.printStackTrace();
		}
	
		return myPositionsArray;
	}
	
	public static int askUserWhatToDo() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What would you like to do? ");  
		System.out.println("1. View Transactions by Zipcode ");
		System.out.println("2. View Totals By Transaction Type ");
		System.out.println("3. View Totals By State ");
		System.out.println("4. View Customer Details By SSN ");
		System.out.println("5. Edit a Customer's Info ");
		System.out.println("6. View a Customer's Bill for a given Month ");
		System.out.println("7. View a Customer's Transaction Between Two Dates ");
		System.out.print("Enter your selection: ");
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			System.out.println("You did not enter a selection.  Program Ending.... ");
			///e.printStackTrace();
		}	
		if (userInput.isEmpty()) {
			System.out.println("Program Ending.... ");
			userInput = "0";
		}
		
		return Integer.parseInt(userInput);  
	}
	
	public static String askUserForBeginDate() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Begin Date in the following format(YYYY-MM-DD): "); 
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if (userInput.isEmpty()) {
			userInput = "2200-12-31";
		}
		
		return userInput; 
	}
	
	public static String askUserForEndDate() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter End Date in the following format(YYYY-MM-DD): "); 
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (userInput.isEmpty()) {
			userInput = "2200-12-31";
		}
		
		return userInput;  	
	}
	
	public static String askUserForZipCode() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Customer Zipcode: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return userInput;  
	}
	
	public static String askUserForMonth() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Month: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return userInput;  
	}
	
	public static String askUserForYear() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Year: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return userInput;  
	}
	
	public static String askUserForTransType() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Transaction Type: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return userInput;  
	}
	
	public static String askUserForAGivenState() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Transaction State: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return userInput;  
	}
	
	public static int askUserForCustSSN() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Customer SSN: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		if (userInput.isEmpty()) {
			userInput = "0";
		}
		
		return Integer.parseInt(userInput); 
	}
	
	public static String askUserForCreditCardNo() {
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Please enter Customer Credit Card Number: ");  
		
		try {
			userInput = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		if (userInput.isEmpty()) {
			userInput = "0";
		}
		
		return userInput; 
	}
	
	public static boolean askUserToUpdateMoreFields() {
		boolean updateMoreFields = false;
		
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Would you like to update additional Customer Information? (Y/N): "); 
		
		try {
			userInput = br.readLine();
			if (userInput.toUpperCase().contains("Y")) {
				updateMoreFields = true;
			} else {
				updateMoreFields = false;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return updateMoreFields; 
	}
	
	public static boolean askUserToExitProgram() {
		boolean exitProgram = false;
		
		String userInput = "";
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Would you like to Exit this application? (Y/N): "); 
		
		try {
			userInput = br.readLine();
			if (userInput.toUpperCase().contains("Y")) {
				exitProgram = true;
			} else {
				exitProgram = false;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		return exitProgram;
	}
}
