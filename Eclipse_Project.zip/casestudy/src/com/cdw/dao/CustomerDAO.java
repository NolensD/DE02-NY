package com.cdw.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cdw.model.Customer;
import com.cdw.resources.Queries;

public class CustomerDAO extends AbstractDAO {
	
	//queries customers by ssn
	public  ArrayList<Customer> queryCustomerBySSN(int ssn){
		ArrayList<Customer> customer = new ArrayList<>();
		establishConnection();
		
		try {
			String sql = Queries.GET_CUSTOMER_BY_SSN;
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setInt(1, ssn);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				customer.add(new Customer(rs.getString("FIRST_NAME"), rs.getString("MIDDLE_NAME"),
						rs.getString("LAST_NAME"), rs.getInt("SSN"), 
						rs.getString("CREDIT_CARD_NO"), rs.getString("APT_NO"),
						rs.getString("STREET_NAME"), rs.getString("CUST_CITY"),
						rs.getString("CUST_STATE"), rs.getString("CUST_COUNTRY"),
						rs.getString("CUST_ZIP"), rs.getInt("CUST_PHONE"), 
						rs.getString("CUST_EMAIL")));
			}
			return customer;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return customer;
	}
	
	public static void UpdateCustomerDetail(String columnToBeModified, String modifiedValue, int ssn ) {
		CustomerDAO cDAO = new CustomerDAO();
		
		if (columnToBeModified.toUpperCase().contains("FIRST")) {
			//update customer FirstName...given the customer's SSN.
			if (cDAO.updateCustomerFirstNameBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer First Name for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("MIDDLE")) {
			//update customer MiddleName...given the customer's SSN.
			if (cDAO.updateCustomerMiddleNameBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Middle Name: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("LAST")) {
			//update customer LastName...given the customer's SSN.
			if (cDAO.updateCustomerLastNameBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Last Name for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("SSN")) {
			//update customer SSN...given the customer's SSN.	
			System.out.println("Not allowed to update ssn for SSN: " + ssn );		
		}
		if (columnToBeModified.toUpperCase().contains("CREDIT")) {	
			if (cDAO.updateCustomerCreditCardNoBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Credit Card No for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("APT")) {
			//update customer Apt No...given the customer's SSN.
			if (cDAO.updateCustomerAptNoBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Apt No for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("STREET")) {
			//update customer Street address...given the customer's SSN.
			if (cDAO.updateCustomerStreetAddressBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Street Address for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("CITY")) {
			//update customer City ...given the customer's SSN.
			if (cDAO.updateCustomerCityBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Street Address for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("STATE")) {
			//update customer State ...given the customer's SSN.
			if (cDAO.updateCustomerStateBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer State for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("COUNTRY")) {
			//update customer Country ...given the customer's SSN.
			if (cDAO.updateCustomerCountryBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer State for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("ZIP")) {
			//update customer Zip ...given the customer's SSN.
			if (cDAO.updateCustomerZipBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Zip for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("PHONE")) {
			//update customer Phone ...given the customer's SSN.
			if (cDAO.updateCustomerPhoneBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Phone for SSN: " + ssn );
			}
		}
		if (columnToBeModified.toUpperCase().contains("EMAIL")) {
			//update customer email ...given the customer's SSN.
			if (cDAO.updateCustomerEmailBySSN(ssn, modifiedValue ) == false) {	
				System.out.println("Failed to update customer Email for SSN: " + ssn );
			}
		}
		
		ArrayList<Customer> customer = cDAO.queryCustomerBySSN(ssn);
		System.out.println(customer.get(0).toString());
	}

	
	//update customer FirstName...given the customer's SSN.
	public boolean updateCustomerFirstNameBySSN(int ssn, String firstNameModified ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_FIRST_NAME;
			
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, firstNameModified);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer Middle Name...given the customer's SSN.
	public boolean updateCustomerMiddleNameBySSN(int ssn, String middleNameModified ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_MIDDLE_NAME;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, middleNameModified);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer Last Name...given the customer's SSN.
	public boolean updateCustomerLastNameBySSN(int ssn, String lastNameModified ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_LAST_NAME;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, lastNameModified);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer Credit_Card_No...given the customer's SSN.
	public boolean updateCustomerCreditCardNoBySSN(int ssn, String newCreditCardNo ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_CREDIT_CARD;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newCreditCardNo);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
		
	//update customer Apt No...given the customer's SSN.
	public boolean updateCustomerAptNoBySSN(int ssn, String newAptNo ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_APT_NO;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newAptNo);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer Street address...given the customer's SSN.
	public boolean updateCustomerStreetAddressBySSN(int ssn, String newStreetAddress ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_STREET_NAME;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newStreetAddress);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer city ...given the customer's SSN.
	public boolean updateCustomerCityBySSN(int ssn, String newCity ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_CITY;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newCity);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer State ...given the customer's SSN.
	public boolean updateCustomerStateBySSN(int ssn, String newState ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_STATE;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newState);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer country ...given the customer's SSN.
	public boolean updateCustomerCountryBySSN(int ssn, String newCountry ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_COUNTRY;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newCountry);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer zip ...given the customer's SSN.
	public boolean updateCustomerZipBySSN(int ssn, String newZip ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_ZIP;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newZip);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer zip ...given the customer's SSN.
	public boolean updateCustomerPhoneBySSN(int ssn, String newPhone ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_PHONE;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newPhone);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
	
	//update customer zip ...given the customer's SSN.
	public boolean updateCustomerEmailBySSN(int ssn, String newEmail ){
		establishConnection();
		
		boolean UpdateStatus = true;	
		try {
			String sql = Queries.UPDATE_CUSTOMER_EMAIL;
					     		
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, newEmail);
			ps.setInt(2, ssn);
			
			ps.executeUpdate();
							
		} catch (SQLException e) {
			
			UpdateStatus = false;
			//e.printStackTrace();
		}
		
		return UpdateStatus;
	}
			
}
