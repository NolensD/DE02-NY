package com.cdw.dao;


import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.Resources;

public class AbstractDAO {
	protected static Connection conn = null;
	protected PreparedStatement state = null;
	protected ResultSet result = null;
	
	protected  void establishConnection() {
		
		try {
			//making a new properties object
			Properties prop = new Properties();
			
			//Derives where the db.properties file exists
			FileInputStream fs = new FileInputStream(this.getClass().getClassLoader().getResource("com/cdw/resources/db.properties").getFile());
			prop.load(fs);
			prop.load(fs);
			
			//Initializing variables to store property keys
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String password = prop.getProperty("password");
			
			//knows what type of driver  to load from the reference library
			Class.forName(driver);
			
			//Derives connection from DriverManger's loading of the driver
			conn = DriverManager.getConnection(url, user, password);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
				
		
	}
	
	protected void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
}
