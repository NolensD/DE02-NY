package com.cdw.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cdw.model.CreditCardMonthlyBill;
import com.cdw.model.TransactionForAGivenDate;
import com.cdw.resources.Queries;

public class CreditCardDAO extends AbstractDAO {
	    
		//This Method displays the monthly bill made by a given creditcard number... 
		//for a given month and year. 
		public ArrayList<CreditCardMonthlyBill> queryDisplayMonthlyBillGivenCreditCardNo(int ssn, String creditCard, int month, int year){
			ArrayList<CreditCardMonthlyBill> transactions = new ArrayList<>();
			establishConnection();
			
			try {
				String sql = Queries.GET_MONTHLY_BILL_BY_CC;
									
				PreparedStatement ps = conn.prepareStatement(sql);
				
				ps.setInt(1, ssn);
				ps.setString(2, creditCard);
				ps.setInt(3, month);
				ps.setInt(4, year);
				
				
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
					transactions.add(new CreditCardMonthlyBill(rs.getInt("TRANSACTION_ID"), rs.getInt("DAY"),
							         rs.getInt("MONTH"), rs.getInt("YEAR"), rs.getString("CREDIT_CARD_NO"), rs.getInt("CUST_SSN"), 
							         rs.getInt("BRANCH_CODE"), rs.getString("TRANSACTION_TYPE"), rs.getDouble("TRANSACTION_VALUE") )); 				
				}
				return transactions;
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			return transactions;
		}
}
