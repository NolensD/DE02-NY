package com.cdw.dao;

import java.util.ArrayList;

import com.cdw.model.TransactionForAGivenDate;
import com.cdw.model.TransactionForAGivenState;
import com.cdw.model.TransactionForAGivenType;
import com.cdw.model.TransactionsForAGivenDateRange;
import com.cdw.resources.Queries;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TransactionDAO extends AbstractDAO {
	
	//This Method displays the transactions made by customers 
	//living in a given zipcode for a given month and year. 
	//Order by day in descending order. 
	public ArrayList<TransactionForAGivenDate> queryTransMadeByCust(String zip, String month, String year){
		ArrayList<TransactionForAGivenDate> transactions = new ArrayList<>();
		establishConnection();
		
		try {
			String sql = Queries.GET_TRANS_DETAIL_BY_DATE;
								
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, zip);
			ps.setString(2, month);
			ps.setString(3, year);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				transactions.add(new TransactionForAGivenDate(rs.getInt("TRANSACTION_ID"),rs.getInt("CUST_SSN"),rs.getString("CREDIT_CARD_NO"),rs.getDouble("TRANSACTION_VALUE"),rs.getString("TRANSACTION_TYPE"), rs.getString("CUST_ZIP"),
						rs.getString("DAY"), rs.getString("MONTH"), rs.getString("YEAR"))); 
						
			}
			return transactions;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return transactions;
	}
	
	//This Method displays the  number of transactions and total values of transactions for a given type.  
	public ArrayList<TransactionForAGivenType> queryDisplayTransactionsTotalValue(String transactionType){
		ArrayList<TransactionForAGivenType> transactions = new ArrayList<>();
		try {
			String sql = Queries.GET_TRANS_DETAIL_BY_TYPE;
								
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, transactionType);

			
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				transactions.add(new TransactionForAGivenType(rs.getString("COUNT_TRANSACTION_ID"), 
						         rs.getString("SUM_TRANSACTION_VALUE"),
						         rs.getString("TRANSACTION_TYPE"))); 
						
			}
			return transactions;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return transactions;
	}
	
	//This Method displays the  number of transactions and total values of transactions for branches in a given state.  
	public ArrayList<TransactionForAGivenState> queryDisplayTransactionsTotalValueGivenState(String transactionState){
		ArrayList<TransactionForAGivenState> transactions = new ArrayList<>();
		establishConnection();
		
		try {
			String sql = Queries.GET_TRANS_DETAIL_BY_STATE;
								
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, transactionState);

			
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				transactions.add(new TransactionForAGivenState(rs.getString("BRANCH_CITY"), 
						         rs.getString("COUNT_TRANSACTION_ID"),
						         rs.getString("SUM_TRANSACTION_VALUE")));
		
						
			}
			return transactions;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return transactions;
	}
	
	//This Method displays the transactions made by a customer 
	// given a date range... 
	//Order by Year, Month, day in descending order. 
	public ArrayList<TransactionsForAGivenDateRange> queryTransMadeByCustBetDates(int ssn, Date beginDate, Date EndDate ){
		ArrayList<TransactionsForAGivenDateRange> transactions = new ArrayList<>();
		establishConnection();
		
		try {
			String sql = Queries.GET_TRANS_BY_BET_DATES;
								
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setInt(1, ssn);
			ps.setDate(2, beginDate);
			ps.setDate(3, EndDate);
	
		
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				transactions.add(new TransactionsForAGivenDateRange(rs.getInt("TRANSACTION_ID"),rs.getInt("CUST_SSN"),rs.getString("CREDIT_CARD_NO"),rs.getDouble("TRANSACTION_VALUE"), rs.getString("TRANSACTION_TYPE"),
						rs.getString("YEAR"), rs.getString("MONTH"), rs.getString("DAY"))); 
						
			}
			return transactions;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return transactions;
	}

}
